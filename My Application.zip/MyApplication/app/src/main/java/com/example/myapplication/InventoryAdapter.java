package com.example.myapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {
    private List<InventoryItem> inventoryList;

    public InventoryAdapter(List<InventoryItem> inventoryList) {
        this.inventoryList = inventoryList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_inventory, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        InventoryItem item = inventoryList.get(position);
        holder.textItemNumber.setText(String.valueOf(position + 1)); // Item #
        holder.textLocation.setText(item.getLocation());
        holder.textWeight.setText(item.getWeight());
        holder.textSize.setText(item.getSize());
    }

    @Override
    public int getItemCount() {
        return inventoryList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView textItemNumber, textLocation, textWeight, textSize;

        public ViewHolder(View itemView) {
            super(itemView);
            textItemNumber = itemView.findViewById(R.id.textItemNumber);
            textLocation = itemView.findViewById(R.id.textLocation);
            textWeight = itemView.findViewById(R.id.textWeight);
            textSize = itemView.findViewById(R.id.textSize);
        }
    }
}
package com.example.myapplication.com.example.myapplication

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.SmsManager
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.myapplication.R

class SMSActivity : AppCompatActivity() {

    private lateinit var txtSmsStatus: TextView
    private lateinit var btnRequestSmsPermission: Button
    private lateinit var btnSendSms: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sms)

        txtSmsStatus = findViewById(R.id.txtSmsStatus)
        btnRequestSmsPermission = findViewById(R.id.btnRequestSmsPermission)
        btnSendSms = findViewById(R.id.btnSendSms)

        checkSmsPermission()

        btnRequestSmsPermission.setOnClickListener {
            requestSmsPermission()
        }

        btnSendSms.setOnClickListener {
            sendSmsNotification("+1234567890", "Low Inventory Alert! Restock needed.") // Example phone number & message
        }
    }

    private fun checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            txtSmsStatus.text = "SMS Notifications Enabled"
            btnSendSms.visibility = Button.VISIBLE
            btnRequestSmsPermission.visibility = Button.GONE
        } else {
            txtSmsStatus.text = "SMS Notifications Disabled"
            btnSendSms.visibility = Button.GONE
            btnRequestSmsPermission.visibility = Button.VISIBLE
        }
    }

    private fun requestSmsPermission() {
        requestPermissions(arrayOf(Manifest.permission.SEND_SMS), 1)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            txtSmsStatus.text = "SMS Notifications Enabled"
            btnSendSms.visibility = Button.VISIBLE
            btnRequestSmsPermission.visibility = Button.GONE
            Toast.makeText(this, "Permission Granted", Toast.LENGTH_SHORT).show()
        } else {
            txtSmsStatus.text = "SMS Notifications Disabled"
            Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show()
        }
    }

    private fun sendSmsNotification(phoneNumber: String, message: String) {
        try {
            val smsManager = SmsManager.getDefault()
            smsManager.sendTextMessage(phoneNumber, null, message, null, null)
            Toast.makeText(this, "Notification Sent!", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Failed to Send SMS", Toast.LENGTH_SHORT).show()
        }
    }
}
package com.example.myapplication;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private InventoryAdapter adapter;
    private List<InventoryItem> inventoryList;
    private EditText editItemName, editItemLocation, editItemWeight, editItemSize;
    private Button btnAddItem, btnDelete;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        // Initialize views
        recyclerView = findViewById(R.id.recyclerViewInventory);
        editItemName = findViewById(R.id.editItemName);
        editItemLocation = findViewById(R.id.editItemLocation);
        editItemWeight = findViewById(R.id.editItemWeight);
        editItemSize = findViewById(R.id.editItemSize);
        btnAddItem = findViewById(R.id.btnAddItem);
        btnDelete = findViewById(R.id.btnDelete);

        // Initialize inventory list and adapter
        inventoryList = new ArrayList<>();
        adapter = new InventoryAdapter(inventoryList);

        // Set up RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        // Add item button
        btnAddItem.setOnClickListener(v -> addItem());

        // Delete all items button
        btnDelete.setOnClickListener(v -> deleteAllItems());


    }

    // Method to add new item to inventory
    private void addItem() {
        String name = editItemName.getText().toString().trim();
        String location = editItemLocation.getText().toString().trim();
        String weight = editItemWeight.getText().toString().trim();
        String size = editItemSize.getText().toString().trim();

        if (name.isEmpty() || location.isEmpty() || weight.isEmpty() || size.isEmpty()) {
            Toast.makeText(this, "Please fill out all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // Add item to inventory
        InventoryItem newItem = new InventoryItem(name, location, weight, size);
        inventoryList.add(newItem);
        adapter.notifyItemInserted(inventoryList.size() - 1);

        // Clear input fields
        editItemName.setText("");
        editItemLocation.setText("");
        editItemWeight.setText("");
        editItemSize.setText("");
    }

    // Method to delete all items
    private void deleteAllItems() {
        if (inventoryList.isEmpty()) {
            Toast.makeText(this, "Inventory is already empty", Toast.LENGTH_SHORT).show();
            return;
        }

        inventoryList.clear();
        adapter.notifyDataSetChanged();
        Toast.makeText(this, "All items deleted", Toast.LENGTH_SHORT).show();
    }
}
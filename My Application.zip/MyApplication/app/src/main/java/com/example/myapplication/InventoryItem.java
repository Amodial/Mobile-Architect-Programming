package com.example.myapplication;

public class InventoryItem {
    private String name;
    private String location;
    private String weight;
    private String size;

    public InventoryItem(String name, String location, String weight, String size) {
        this.name = name;
        this.location = location;
        this.weight = weight;
        this.size = size;
    }

    public String getName() {
        return name;
    }

    public String getLocation() {
        return location;
    }

    public String getWeight() {
        return weight;
    }

    public String getSize() {
        return size;
    }
}